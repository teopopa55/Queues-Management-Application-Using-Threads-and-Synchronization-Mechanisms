package DataModel;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.atomic.AtomicInteger;

public class Server implements Runnable
{
    private BlockingQueue<Task> tasks;
    private AtomicInteger waitingPeriod;

    public Server() {
        this.tasks = new LinkedBlockingDeque<>();
        this.waitingPeriod = new AtomicInteger(0);
    }

    public int getWaitingPeriod() {
        return waitingPeriod.get();
    }

    public void setWaitingPeriod(AtomicInteger waitingPeriod) {
        this.waitingPeriod = waitingPeriod;
    }

    public void addTask(Task newTask) {
        tasks.add(newTask);
        waitingPeriod.addAndGet(newTask.getServiceTime());
     }

     @Override
     public void run() {
     while (true) {
          try
          {
              Task task=tasks.take();
             while(task.getServiceTime()>0)
             {
                 task.setServiceTime(task.getServiceTime()-1);//decrease task time
                 // decrement the waitingPeriod
                 waitingPeriod.decrementAndGet();//decrease total waiting time
                 // stop the thread so that each unit of service time is processed as one second instead of instantly
                 Thread.sleep(1000);
             }

          }catch(InterruptedException e)
          {
            Thread.currentThread().interrupt();
          }

         }
     }

        public BlockingQueue<Task> getTasks()
        {
            return tasks;
        }



}
