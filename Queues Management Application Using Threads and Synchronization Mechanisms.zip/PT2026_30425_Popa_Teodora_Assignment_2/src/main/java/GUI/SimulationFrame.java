package GUI;

import BusinessLogic.SelectionPolicy;
import BusinessLogic.SimulationManager;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;


public class SimulationFrame extends JFrame
{
    //input fields on the left
    private JTextField timeLimitField = new JTextField("100");
    private JTextField minArrivalField= new JTextField("0");
    private JTextField maxArrivalField= new JTextField("90");
    private JTextField minProcessingField = new JTextField("2");
    private JTextField maxProcessingField = new JTextField("10");
    private JTextField numberOfServersField = new JTextField("3");
    private JTextField numberOfClientsField = new JTextField("100");

    //to choose between shortest queue and shortest time
    private JList<String> selectionPolicy;

    //for table
    private JTextArea logArea=new JTextArea();

    //for statistics part
    private JTextField avgWaitingField = new JTextField();
    private JTextField avgServiceField = new JTextField();
    private JTextField peakHourField = new JTextField();

    private JButton startButton=new JButton("Start");

    public void registerListeners()
    {
        startButton.addActionListener(e->{
            SimulationManager manager =new SimulationManager();

            manager.timeLimit=Integer.parseInt(timeLimitField.getText());
            manager.minArrivalTime=Integer.parseInt(minArrivalField.getText());
            manager.maxArrivalTime=Integer.parseInt(maxArrivalField.getText());
            manager.maxProcessingTime=Integer.parseInt(maxProcessingField.getText());
            manager.minProcessingTime=Integer.parseInt(minProcessingField.getText());
            manager.numberOfServers=Integer.parseInt(numberOfServersField.getText());
            manager.numberOfClients=Integer.parseInt(numberOfClientsField.getText());
            manager.selectionPolicy= SelectionPolicy.valueOf(selectionPolicy.getSelectedValue());

            if(manager.minArrivalTime>manager.maxArrivalTime)
            {
                JOptionPane.showMessageDialog(this, "Min arrival time MUST be <= Max arrival time");
                return;
            }

            if(manager.minProcessingTime>manager.maxProcessingTime)
            {
                JOptionPane.showMessageDialog(this, "Min processing time MUST be <= Max processing time");
                return;
            }

            if(manager.timeLimit<manager.maxArrivalTime || manager.timeLimit<manager.maxProcessingTime)
            {
                JOptionPane.showMessageDialog(this, "Limit time MUST be <= Max Arrival Time AND <= Max Processing Time");
                return;
            }

            manager.setFrame(this);
            manager.setupData();
            Thread t= new Thread(manager);
            t.start();
        });
    }
    public SimulationFrame()
    {
        setTitle("Queue Management");
        setSize(1000,600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //horizontal gap and vertical gap
        setLayout(new BorderLayout(10,10));

        initLeftPanel();
        initRightPanel();
        registerListeners();
    }

    //here the fields needed for the simulation will be initialized
    private void initLeftPanel()
    {
        JPanel left= new JPanel(new GridLayout(9,2,5,5));
        left.setBorder(new TitledBorder("Data Input"));
        left.setPreferredSize(new Dimension(250,600));

        DefaultListModel<String> model = new DefaultListModel<>();
        model.addElement("SHORTEST_QUEUE");
        model.addElement("SHORTEST_TIME");

       selectionPolicy= new JList<>(model);
       selectionPolicy.setSelectedIndex(1);//for default

       left.add(new JLabel("Time Limit:"));
       left.add(timeLimitField);

       left.add(new JLabel("Min Arrival Time"));
       left.add(minArrivalField);

       left.add(new JLabel("Max Arrival Time"));
       left.add(maxArrivalField);

       left.add(new JLabel("Min Proc Time:"));
       left.add(minProcessingField);

       left.add(new JLabel("Max Proc Time:"));
       left.add(maxProcessingField);

       left.add(new JLabel("Servers: "));
       left.add(numberOfServersField);

       left.add(new JLabel("Clients: "));
       left.add(numberOfClientsField);

       left.add(new JLabel("Policy: "));
       left.add(new JScrollPane(selectionPolicy));

       left.add(new JLabel(""));
       left.add(startButton);

       add(left, BorderLayout.WEST);

   }

   //here the results: table+statistics will be shown
    private void initRightPanel()
    {
       JPanel right= new JPanel(new BorderLayout(10,10));

       //log area
       logArea.setEditable(false);
       JScrollPane scroll=new JScrollPane(logArea);
       scroll.setBorder(new TitledBorder("Simulation Table"));

       //results panner
        JPanel results=new JPanel(new GridLayout(3,2,5,5));
        results.setBorder(new TitledBorder("Statistics"));

        avgWaitingField.setEditable(false);
        avgServiceField.setEditable(false);
        peakHourField.setEditable(false);

        results.add(new JLabel("Average Waiting Time:"));
        results.add(avgWaitingField);
        results.add(new JLabel("Average Service Time:"));
        results.add(avgServiceField);
        results.add(new JLabel("Peak Hour:"));
        results.add(peakHourField);

        right.add(scroll, BorderLayout.CENTER);
        right.add(results, BorderLayout.SOUTH);

        add(right, BorderLayout.CENTER);

    }

    public JTextField getTimeLimitField() { return timeLimitField;}
    public JTextField getMaxProcessingField() {return maxProcessingField;}
    public JTextField getMinProcessingField() {return minProcessingField;}
    public JTextField getNumberOfServersField() {return numberOfServersField;}
    public JTextField getNumberOfClientsField() {return numberOfClientsField;}
    public JList<String> getSelectionPolicy() {return selectionPolicy;}
    public JButton getStartButton() {return startButton;}

    public void setAvgWaitingField(double value) {
        SwingUtilities.invokeLater(()->
                avgWaitingField.setText(String.valueOf(value))
        );
    }

    public void setAvgServiceField(double value) {
        SwingUtilities.invokeLater(()->
                avgServiceField.setText(String.valueOf(value))
        );
    }

    public void setPeakHourField(int value) {
        SwingUtilities.invokeLater(()->
                peakHourField.setText(String.valueOf(value))
        );
    }

    public void appendLog(String text)
    {
        SwingUtilities.invokeLater(()->logArea.append(text+"\n"));
    }

    public static void main(String[] args)
    {
         SwingUtilities.invokeLater(()->{
             SimulationFrame frame= new SimulationFrame();
             frame.setVisible(true);
             SimulationManager gen = new SimulationManager();
             Thread t = new Thread(gen);
             t.start();

         });


    }

}
