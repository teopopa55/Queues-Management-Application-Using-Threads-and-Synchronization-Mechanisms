package BusinessLogic;

import DataModel.Server;
import DataModel.Task;

import java.util.ArrayList;
import java.util.List;

public class Scheduler {

    private List<Server> servers;
    private int maxNoServers;
    private Strategy strategy;

    public Scheduler( int maxNoServers) {
        this.servers = new ArrayList<>();
        this.maxNoServers = maxNoServers;

        for(int i=0;i<maxNoServers;i++)
        {
           Server server=new Server();
           servers.add(server);

           Thread t = new Thread(server);
           t.start();
        }
    }

    public void setServers(List<Server> servers) {
        this.servers = servers;
    }

    public int getMaxNoServers() {
        return maxNoServers;
    }

    public void setMaxNoServers(int maxNoServers) {
        this.maxNoServers = maxNoServers;
    }

    public Strategy getStrategy() {
        return strategy;
    }

    public void setStrategy(Strategy strategy) {
        this.strategy = strategy;
    }

    public void changeStrategy(SelectionPolicy policy)
    {
        // apply strategy pattern in order to instantiate the strategy
        // with the concrete strategy corresponding to policy
        if (policy == SelectionPolicy.SHORTEST_QUEUE) {
             strategy = new ShortestQueueStrategy();
             }
        if (policy == SelectionPolicy.SHORTEST_TIME) {
             strategy = new ShortestTimeStrategy();
             }
    }

         public void dispatchTask(Task t)
         {
         // call the strategy addTask method
             strategy.addTask(servers,t); //polymorphism uses the correct implementation
         }

         public List<Server> getServers() {
         return servers;
        }
}
