package BusinessLogic;

import DataModel.Server;
import DataModel.Task;
import GUI.SimulationFrame;

import java.io.PrintWriter;
import java.util.*;

public class SimulationManager implements Runnable {
    // following data read from GUI
    // maximum processing time, it is read from GUI
    public int minArrivalTime=0;
    public int maxArrivalTime=90;
    public int timeLimit=100;
    public int maxProcessingTime = 10;
    public int minProcessingTime = 2;
    public int numberOfServers = 3;
    public int numberOfClients = 100;
    public SelectionPolicy selectionPolicy = SelectionPolicy.SHORTEST_TIME;

    // entity responsible with queue management and client distribution
    private Scheduler scheduler;
    // frame for displaying simulation
    private SimulationFrame frame;
    // pool of tasks (client shopping in the store)
    private List<Task> generatedTasks;

    public SimulationManager()
    {

    }

    private void generateNRandomTasks() {
        generatedTasks=new ArrayList<>();
        Random rand= new Random();
        // generate N random tasks
        for(int i=1;i<=numberOfClients;i++)
        {
            // - random processing time
            // minProcessingTIme < processingTime < maxProcessingTime
            int serviceTime=rand.nextInt(maxProcessingTime-minProcessingTime+1)+minProcessingTime;

            // - random arrivalTime
            int arrivalTime= rand.nextInt(maxArrivalTime-minArrivalTime+1)+minArrivalTime;

            Task task=new Task(i,arrivalTime,serviceTime);
            generatedTasks.add(task);
        }
        // sort list with respect to arrivalTime
        generatedTasks.sort(Comparator.comparingInt(Task::getArrivalTime));
    }

    @Override
    public void run() {
        int currentTime = 0;

        int totalWaitingTime=0;
        int totalServiceTime=0;
        int peakHour=0;
        int maxClients=0;

        PrintWriter writer=null;
        try{
            writer=new PrintWriter("test_test.txt");
        }catch(Exception e)
        {
            e.printStackTrace();
        }


        while (currentTime < timeLimit) {
           // System.out.println("Time: "+ currentTime);
            StringBuilder log= new StringBuilder();
            log.append("Time ").append(currentTime).append("\n");

            //waiting clients
           // System.out.println("Waiting clients: ");
            log.append("Waiting clients: ");
            for(Task t:generatedTasks)
            {
                //System.out.println("(" + t.getId() + ", " + t.getArrivalTime() + ", " + t.getServiceTime() + ")");
                log.append("(").append(t.getId()).append(", ")
                        .append(t.getArrivalTime()).append(", ")
                        .append(t.getServiceTime()).append(")");
            }
            //System.out.println();
            log.append("\n");

            // iterate generatedTasks list and pick tasks that have the arrivalTime = currentTime
             Iterator<Task> iterator= generatedTasks.iterator();
             while(iterator.hasNext())
             {
                 Task task=iterator.next();
                 if(task.getArrivalTime()==currentTime)
                 {
                     // - send task to queue by calling dispatchTask method from BusinessLogic.Scheduler
                      scheduler.dispatchTask(task);
                      totalServiceTime+= task.getServiceTime();
                     totalWaitingTime+=task.getWaitingTime();
                     // - delete client from list
                     iterator.remove();
                 }

             }


             int totalClientsNow=0;
             //print queues
            int i=1;
            for(Server s: scheduler.getServers())
            {
                //System.out.println("Queue "+i+": ");
                log.append("Queue ").append(i).append(": ");

                int queueSize= s.getTasks().size();
                totalClientsNow+=queueSize;

                for(Task t: s.getTasks())
                {
                    //System.out.println("("+t.getId()+", "+t.getArrivalTime()+", "+t.getServiceTime()+")");
                    log.append("(").append(t.getId()).append(", ")
                            .append(t.getArrivalTime()).append(", ")
                            .append(t.getServiceTime()).append(")");
                }
                //System.out.println();
                log.append("\n");
                i++;
            }

            //peak hour= when most clients
            if(totalClientsNow>maxClients)
            {
                maxClients=totalClientsNow;
                peakHour=currentTime;
            }
            // update UI frame
            log.append("-----------------------\n");
            //System.out.println("-----------------------");
            // wait an interval of 1 second

            //send log to GUI
            if(frame!=null)
                frame.appendLog(log.toString());

            if(writer!=null)
            {
                writer.println(log.toString());
            }

            try{
                Thread.sleep(1000);
            }catch(InterruptedException e)
            {
                Thread.currentThread().interrupt();
            }
            currentTime++;
        }

        //compute average service time and waiting time
        double avgService=(double) totalServiceTime/numberOfClients;
        double avgWaitingTime=(double)totalWaitingTime/numberOfClients;

        if(frame!=null)
        {
            frame.setAvgWaitingField(avgWaitingTime);
            frame.setAvgServiceField(avgService);
            frame.setPeakHourField(peakHour);
        }

        if(writer!=null)
        {
            writer.println("Average waiting time: "+avgWaitingTime);
            writer.println("Average service time: "+avgService);
            writer.println("Peak hour: "+peakHour);
            writer.close();
        }
    }

    public void setupData()
    {
        scheduler= new Scheduler(numberOfServers);
        scheduler.changeStrategy(selectionPolicy);
        generateNRandomTasks();
    }

    public void setFrame(SimulationFrame frame)
    {
        this.frame=frame;
    }

}