package BusinessLogic;

import DataModel.Server;
import DataModel.Task;

import java.util.List;

public class ShortestQueueStrategy implements Strategy
{
    @Override
    public void addTask(List<Server> servers, Task t) {
        Server best=servers.get(0);
        for(Server s:servers)
        {
            if(s.getTasks().size()<best.getTasks().size())
            {
                best=s;
            }
        }
        t.setWaitingTime(best.getWaitingPeriod());
        best.addTask(t);
    }
}
